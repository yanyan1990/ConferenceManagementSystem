package com.example.conferencemanagementsystem;


import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class RegisterActivity extends FragmentActivity{
	Button registerButton;
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        registerButton=(Button)findViewById(R.id.registerbutton);
        registerButton.setOnClickListener(new OnClickListener() {
			
			public void onClick(View arg0) {
				Toast toast= Toast.makeText(RegisterActivity.this,"ע��ɹ���",Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.TOP,0,350);
	          	toast.show();
				
			}
		});
	}

}
