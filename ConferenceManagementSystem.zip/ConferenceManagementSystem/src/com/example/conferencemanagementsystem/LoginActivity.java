package com.example.conferencemanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends FragmentActivity {

	RadioGroup radioGroup;
	Button loginButton;
	TextView goRegisterTextView;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		radioGroup = (RadioGroup) findViewById(R.id.roleradiogroup);
		loginButton = (Button) findViewById(R.id.loginbutton);
		goRegisterTextView = (TextView) findViewById(R.id.gotoregister);

		loginButton.setOnClickListener(new OnClickListener() {
			
			public void onClick(View arg0) {
				if(radioGroup.getCheckedRadioButtonId()==R.id.roleFirst){
					Toast toast=Toast.makeText(LoginActivity.this,"�������Ĺ�����Ա��¼�ɹ���",Toast.LENGTH_SHORT);
					toast.setGravity(Gravity.TOP,0,350);
		          	toast.show();
					Intent intent1 =new Intent(LoginActivity.this,HostActivity.class);
					startActivity(intent1);
				}else{
					Toast toast=Toast.makeText(LoginActivity.this,"�������췽��¼�ɹ���",Toast.LENGTH_SHORT);
					toast.setGravity(Gravity.TOP,0,350);
		          	toast.show();
					Intent intent2=new Intent(LoginActivity.this,ConferencePlanActivity.class);
					startActivity(intent2);
				}
				
			}
		});
		goRegisterTextView.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(LoginActivity.this,
						RegisterActivity.class);
				startActivity(intent);
			}
		});
	}

}
