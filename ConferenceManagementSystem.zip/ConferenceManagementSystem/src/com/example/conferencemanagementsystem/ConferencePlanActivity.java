package com.example.conferencemanagementsystem;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ConferencePlanActivity extends FragmentActivity {
	Button conferenceCommitButton;
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conferencerentplan);
        conferenceCommitButton=(Button)findViewById(R.id.conferencecommitbutton);
        conferenceCommitButton.setOnClickListener(new OnClickListener() {
			
			public void onClick(View arg0) {
				Toast toast= Toast.makeText(ConferencePlanActivity.this,"�ύ�ɹ���",Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.TOP,0,350);
	          	toast.show();
				
			}
		});
	}

}
